package com.example.mailchat;

public class Constants {

    public static final long START_TIME = 60000;

}
